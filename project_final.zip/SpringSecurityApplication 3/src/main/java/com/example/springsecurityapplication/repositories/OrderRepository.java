package com.example.springsecurityapplication.repositories;

import com.example.springsecurityapplication.enumm.Status;
import com.example.springsecurityapplication.models.Order;
import com.example.springsecurityapplication.models.Person;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface OrderRepository extends JpaRepository<Order, Integer> {

    List<Order> findByPerson(Person person);

    @Query(value = "select * from orders where number LIKE %?1", nativeQuery = true)
    List<Order> findByLastText(String title);

    @Modifying
    @Query(value = "update orders set status=?1 where id=?2", nativeQuery = true)
    void saveStatus(int status, int id);
}
